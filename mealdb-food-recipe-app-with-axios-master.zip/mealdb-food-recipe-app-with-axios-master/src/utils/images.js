import header_image from "../assets/images/header_image.jpg";
import loader from "../assets/images/loader.svg";

export { header_image, loader };